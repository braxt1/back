require("dotenv").config();
const db = require("knex")({
  client: "pg",
  connection: {
    host: 'localhost',
    user: 'crypwbbt_root',
    password: 'Notreally$',
    database: 'crypwbbt_azcrypt',
  },
});

module.exports = db;
